const express = require("express");
const bcryptjs = require("bcryptjs");
const userRouter = express.Router();
const jwt = require("jsonwebtoken");
const auth = require("../middleware/auth");
const User = require('../models/User');

userRouter.post("/signup", async (req, res) => {
    try {
        const { ugaID, password, confirmPassword } = req.body;
        if(!ugaID || !password || !confirmPassword) {
            return res.status(400).json({ msg: "Please enter all the fields" });
        }
        if(password.length < 6) {
            return res.status(400).json({ msg: "Password should be at least 6 characters" });
        }
        if(confirmPassword !== password) {
            return res.status(400).json({ msg: "Both the passwords don't match" });
        }
        
        const existingUser = await User.findOne({ ugaID });
        if(existingUser) {
            return res.status(400).json({ msg: "User with the same UGA ID already exists" });
        }

        const hashedPassword = await bcryptjs.hash(password, 8);
        const newUser = new User({ ugaID, password: hashedPassword });

        const savedUser = await newUser.save();
        console.log(savedUser.ugaID);
        res.json(savedUser);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

userRouter.post("/login", async (req, res) => {
    try {
        const { ugaID, password } = req.body;
        if(!ugaID || !password) {
            return res.status(400).json({ msg: "Please enter all the fields" });
        }

        const user = await User.findOne({ ugaID });
        if(!user) {
            return res.status(400).send({ msg: "User with this UGA ID does not exist " });
        }

        const isMatch = await bcryptjs.compare(password, user.password);

        if(!isMatch) {
            return res.status(400).send({ msg: "Incorrect password." });
        }
        const token = jwt.sign({ id: user._id }, "passwordKey");
        res.json({ token, user: { id: user._id, ugaID: user.ugaID } });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

userRouter.post("/tokenIsValid", async (req, res) => {
    try {
        const token = req.header("x-auth-token");
        if(!token) return res.json(false);
        const verified = jwt.verify(token, "passwordKey");
        if(!verified) return res.json(false);
        const user = await User.findById(verified.id);
        if(!user) return res.json(false);
        return res.json(true);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

userRouter.get("/", auth, async (req, res) => {
    const user = await User.findById(req.user);
    res.json({
        ugaID: user.ugaID,
        id: user._id,
    });
});

module.exports = userRouter;